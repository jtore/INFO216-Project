# INFO216 Project

To run the program,

1. First go to http://sandbox.i2s.uib.no/bigdata/sparql and in the Update section,
 add the file or insert the data from one of our datasets. NB! The largest dataset will not work in the sandbox environment.

2. Run the program. T